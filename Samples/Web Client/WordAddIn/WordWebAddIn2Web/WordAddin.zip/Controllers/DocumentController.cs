﻿using HP.HPTRIM.SDK;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http;
using WordWebAddIn2Web.Model;

namespace WordWebAddIn2Web.Controllers
{

    public class DocumentController : BaseController
    {

        public async System.Threading.Tasks.Task<IEnumerable<RecordDocument>> Get()
        {
            string userUPN = await GetUser();
            List<RecordDocument> records = new List<RecordDocument>();
            using (Database db = getDatabase(userUPN))
            {
                TrimMainObjectSearch search = new TrimMainObjectSearch(db, BaseObjectTypes.Record);

                TrimSearchClause clause = new TrimSearchClause(db, BaseObjectTypes.Record, SearchClauseIds.Favorite);
                search.AddSearchClause(clause);

                TrimSearchClause extClause = new TrimSearchClause(db, BaseObjectTypes.Record, SearchClauseIds.RecordExtension);
                extClause.SetCriteriaFromString("docx");

                search.AddSearchClause(extClause);
                search.And();

                foreach (Record record in search)
                {
                    records.Add(new RecordDocument(record));
                }

                return records;
            }
         }


        // GET api/<controller>
        public async System.Threading.Tasks.Task<HttpResponseMessage> Get(long id)
        {
            string userUPN = await GetUser();

            using (Database db = getDatabase(userUPN))
            {
                Record record = new Record(db, id);

                if (!record.IsDocumentInClientCache)
                {
                    record.LoadDocumentIntoClientCache();
                }

                if (!record.IsCheckedOut)
                {
                    record.GetDocument(null, true, null, null);
                }
                else if (record.CheckedOutTo.Uri != db.CurrentUser.Uri)
                {
                    throw new Exception($"Record already checkout out to {record.CheckedOutTo.FullFormattedName}");
                }



                Byte[] bytes = File.ReadAllBytes(record.DocumentPathInClientCache);
                string rr = Convert.ToBase64String(bytes);

                return new HttpResponseMessage()
                {
                    Content = new StringContent(
                        rr,
                        Encoding.UTF8,
                        "text/plain"
                    )
                };
            }

        }

        public async System.Threading.Tasks.Task<RecordDocument> Post(RecordDocument recordDocument)
        {
           // string result = await Request.Content.ReadAsStringAsync();

            string userUPN = await GetUser();
           

            using (Database db = getDatabase(userUPN))
            {
                Record record = new Record(db, recordDocument.Id);

            //    byte[] data = Convert.FromBase64String(result);

                string fileName = Path.Combine("c:\\junk", "WordAddin", record.SuggestedFileName);

                using (var file = File.Create(fileName)) {
                    file.Write(recordDocument.Data, 0, recordDocument.Data.Length);
                    file.Close();
                }
                record.SetDocument(new InputDocument(fileName), true, false, null);
                record.Save();

                File.Delete(fileName);
                return new RecordDocument(record);
            }

          
        }
    }
}